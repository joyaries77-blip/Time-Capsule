
  # Time Capsule Interface Design

  This is a code bundle for Time Capsule Interface Design. The original project is available at https://www.figma.com/design/IsVdJYxGWev04eTWfhPU2X/Time-Capsule-Interface-Design.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  